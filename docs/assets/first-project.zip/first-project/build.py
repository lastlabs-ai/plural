"""Compile Plural's typed Environment and author complete schema-v2 project files.

Run from this directory. Generated YAML files are intentionally reviewable.
"""

from pathlib import Path

import yaml
from environment.world import SupportQueue

from plural import (
    AgentDefinition,
    DeterministicVerifier,
    EnvironmentRuntime,
    EvidenceContract,
    ExecutionLimits,
    NativeAction,
    VerifierRuntime,
)
from plural.cli.scaffold import BenchmarkFile, JobFile, TaskFile

ROOT = Path(__file__).resolve().parent


def write(relative, value):
    path = ROOT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(value.model_dump(mode="json", exclude_none=True), sort_keys=False)
    )


world = SupportQueue(
    runtime=EnvironmentRuntime(
        provider="local", network="full", targets={"local"}, allow_unsafe_local=True
    ),
    limits=ExecutionLimits(max_turns=6, max_seconds=120),
)
definition = world.definition()
# Python declarations supply names, descriptions and parameter schemas.
# Package Jobs execute commands, so bind each compiled action to its adapter.
# reset is the episode API, not an Agent tool.
actions = tuple(
    NativeAction.model_validate(
        {
            **item.model_dump(),
            "kind": "command",
            "command": ["python", "commands.py", item.name],
        }
    )
    for item in definition.actions
)
definition = definition.model_copy(
    update={"actions": actions, "reset_command": ("python", "commands.py", "reset")}
)
write("environment/environment.yaml", definition)
write(
    "verifiers/correct.yaml",
    DeterministicVerifier(
        name="correct-category",
        command=("python", "correct.py"),
        runtime=VerifierRuntime(provider="local", network="full"),
        evidence=EvidenceContract(
            observation_paths=("category", "done"),
            state_paths=("expected",),
            include_hidden_state=True,
        ),
    ),
)
for ticket_id in ("ticket-1", "ticket-2", "ticket-3"):
    write(
        f"tasks/{ticket_id}.yaml",
        TaskFile(
            task_id=ticket_id,
            instructions="Read the open ticket, categorize it correctly, then give a brief final confirmation. Stop after categorization.",
            environment=Path("../environment"),
            verifiers=(Path("../verifiers/correct.yaml"),),
            info={"ticket_id": ticket_id},
            metadata={"split": "evaluation"},
        ),
    )
for name, instructions in (
    (
        "careful",
        "Inspect the ticket before categorizing it. Use the Environment actions; a final message alone does not change the ticket.",
    ),
    ("concise", "Complete the task using the available actions. Be concise."),
):
    write(
        f"agents/{name}.yaml",
        AgentDefinition(
            name=name,
            model="gpt-4.1-mini",
            instructions=instructions,
            secret_names=("OPENAI_API_KEY",),
        ),
    )
write(
    "benchmark.yaml",
    BenchmarkFile(
        name="support-triage", tasks=tuple(Path(f"tasks/ticket-{n}.yaml") for n in (1, 2, 3))
    ),
)
write(
    "job.yaml",
    JobFile(
        source_kind="task",
        source=Path("tasks/ticket-1.yaml"),
        agents=(Path("agents/careful.yaml"),),
    ),
)
print("Built Environment, Verifier, three Tasks, two Agents, Benchmark, and Job with Plural.")
